#version 330
#extension GL_ARB_separate_shader_objects : require

// K1 full-screen vertex program. Own file on purpose: the vanilla one is named differently
// from version to version, and a missing program breaks the whole effect.
// Vertex 0 -> (0,0), 1 -> (2,0), 2 -> (0,2), 3 -> (2,2): one oversized triangle (or quad) over the viewport.

layout(location = 0) out vec2 texCoord;

void main() {
    vec2 corner = vec2(float(gl_VertexIndex & 1), float(gl_VertexIndex >> 1)) * 2.0;
    texCoord = corner;
    gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
}
