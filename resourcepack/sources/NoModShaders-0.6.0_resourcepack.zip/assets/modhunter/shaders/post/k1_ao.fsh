#version 330
#extension GL_ARB_separate_shader_objects : require

// K1 v3: soft contact shadows (screen-space ambient occlusion) from the depth buffer only.
// Idea: on any flat surface, 1/distance changes linearly across the screen. So for two samples
// on opposite sides of a pixel, the average of their 1/distance equals the pixel's own value.
// Inside a corner or crease (wall meets ground, under a ledge, between leaves) both samples are
// nearer to the camera, the average is larger, and that excess is the occlusion.
// Edge safety: a pair is ignored as soon as its second difference in depth is large (z1 + z2 - 2 z0,
// small on any plane even at grazing angles, large at a silhouette of a tree in front of a hill),
// so no dark halos around objects.
// v3 against the dot noise on leaves seen in the v2 diagnosis: no per-pixel rotation pattern any more
// (that was the dot grid), and a second output "roughness" (g) = how much the neighbours lie BEHIND
// this pixel. Concave corners never have that; see-through cutout textures (leaves, grass, flowers)
// have it all over, because front texels and holes alternate. The grade pass averages the roughness
// over 5x5 pixels and fades the occlusion out where it is high, so leaves stay calm and do not flicker.
// CPU check (tools/ao_check.py, synthetic scene): wall/floor corner up to 0.42, flat floor 0.00,
// 3-layer leaf block with holes mean 0.002, 99 % below 0.03 (v2 method: mean 0.095, 99 % 0.76).
// Output: r = occlusion 0..1 (0 = open), fades out with distance; g = roughness 0..1.

uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 DepthSize;
};

layout(std140) uniform K1Ao {
    float Radius;       // world radius of the probe in blocks
    float Focal;        // projection scale: pixels per block at distance 1, as share of the screen height
    float MaxDistance;  // occlusion fades out up to this distance in blocks
    float Near;         // near clipping plane of the game in blocks
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

// works for normal and reversed depth: sky is 1.0 in a normal buffer, 0.0 in a reversed one
float k1_depth_x(float d, float reversed) {
    return reversed > 0.5 ? d : 1.0 - d;
}

float k1_linear(float d, float reversed) {
    return Near / max(k1_depth_x(d, reversed), 1e-7);
}

void main() {
    float reversed = texture(DepthSampler, vec2(0.5)).r < 0.5 ? 1.0 : 0.0;
    float d0 = texture(DepthSampler, texCoord).r;
    if (k1_depth_x(d0, reversed) < 1e-6) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);   // sky
        return;
    }
    float z0 = k1_linear(d0, reversed);
    if (z0 > MaxDistance) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    float w0 = 1.0 / z0;
    float rpx = clamp(Radius * Focal * OutSize.y / z0, 2.0, 40.0);
    float limit = Radius * 1.6 + z0 * 0.02;     // largest second difference that still counts as one surface

    float occ = 0.0;
    float behind = 0.0;
    for (int i = 0; i < 6; i++) {
        float a = float(i) * 0.5236 + 0.2618;     // 6 fixed directions over half a circle, 15 degrees off the axes
        float r = (i % 2 == 0) ? rpx : rpx * 0.45;
        vec2 o = vec2(cos(a), sin(a)) * r / DepthSize;
        float z1 = k1_linear(texture(DepthSampler, texCoord + o).r, reversed);
        float z2 = k1_linear(texture(DepthSampler, texCoord - o).r, reversed);
        float valid = 1.0 - smoothstep(limit * 0.5, limit, abs(z1 + z2 - 2.0 * z0));
        float crease = ((1.0 / z1 + 1.0 / z2) * 0.5 - w0) / w0;   // relative excess of 1/distance
        float scale = (i % 2 == 0) ? Radius : Radius * 0.45;
        float e = crease * z0 / scale;
        occ += clamp(e, 0.0, 1.0) * valid;
        behind += clamp(-e, 0.0, 1.0);
    }
    occ /= 6.0;
    occ *= 1.0 - smoothstep(MaxDistance * 0.6, MaxDistance, z0);
    fragColor = vec4(occ, behind / 6.0, 0.0, 1.0);
}
