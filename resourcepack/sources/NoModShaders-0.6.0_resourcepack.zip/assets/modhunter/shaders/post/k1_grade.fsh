#version 330
#extension GL_ARB_separate_shader_objects : require

// NoMod Shaders v6 (K1 Day 6) final look pass, shared by all stages (Lite, Default, Cinematic and their diagnosis variants).
// Order: light sharpening -> linear light -> contact shadows (AO) -> glow -> exposure ->
// soft highlight roll-off -> back to gamma -> contrast curve -> split toning (cool shadows,
// warm highlights) -> saturation, vibrance, warm boost, deeper sky -> vignette.
// Lite reads its glow straight from the frame (two rings of 8 taps) instead of the blur chain.
// Debug: with Split > 0 the left part of the screen shows a reference (Debug 1: the untouched
// frame, Debug 2: the contact shadow buffer), a thin white line marks the split.

uniform sampler2D SceneSampler;
uniform sampler2D GlowSampler;
uniform sampler2D AoSampler;
uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 SceneSize;
    vec2 GlowSize;
    vec2 AoSize;
    vec2 DepthSize;
};

layout(std140) uniform K1Grade {
    vec4 ShadowTint;     // rgb multiplier for the dark end, a = amount
    vec4 HighlightTint;  // rgb multiplier for the bright end, a = amount
    float Exposure;
    float WhitePoint;    // linear value that maps to white in the roll-off
    float Contrast;      // 0 = none, 1 = full smoothstep curve
    float Saturation;    // 1 = unchanged
    float Vibrance;      // extra saturation for muted colours only
    float WarmBoost;     // extra saturation for orange/gold hues (sunsets, torch light)
    float SkyBoost;      // extra saturation for strongly coloured sky (zenith blue, sunset)
    float GlowMix;
    float LiteGlow;      // > 0: glow from the frame itself (Lite), value = strength
    float AoStrength;    // 0 = contact shadows off (AO buffer not read)
    float Sharpen;       // 0 = off
    float Vignette;      // darkening at the corners (0..1)
    float Falloff;       // larger = vignette starts further out
    float Near;          // near clipping plane in blocks (for the depth-aware AO blur)
    float Split;         // 0 = off, else x position of the reference split (0..1)
    float Debug;         // 1 = reference shows the untouched frame, 2 = reference shows the AO buffer
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// extended Reinhard on luminance: keeps hue, compresses only the top end
vec3 rolloff(vec3 lin, float white) {
    float l = luma(lin);
    float mapped = l * (1.0 + l / (white * white)) / (1.0 + l);
    return lin * (mapped / max(l, 1e-5));
}

float depth_x(float d, float reversed) {
    return reversed > 0.5 ? d : 1.0 - d;
}

float linear_depth(float d, float reversed) {
    return Near / max(depth_x(d, reversed), 1e-7);
}

vec3 lite_glow(vec2 uv) {
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 16; i++) {
        float ring = i < 8 ? 7.0 : 16.0;
        float a = float(i) * 0.7854 + (i < 8 ? 0.0 : 0.3927);
        vec2 o = vec2(cos(a), sin(a)) * ring / SceneSize;
        vec3 c = texture(SceneSampler, uv + o).rgb;
        float l = luma(c);
        float w = smoothstep(0.72, 0.98, l);
        acc += pow(c, vec3(2.2)) * w * (i < 8 ? 0.6 : 0.4);
    }
    return acc / 8.0;
}

// depth-aware blur of the contact shadow buffer: centre plus 4 diagonal taps on a 2-pixel grid (v5: 5 instead of
// 9 taps, covers the same 5x5 pixels; the AO pass already samples in 6 fixed directions, so the result stays smooth).
// Neighbours at a very different distance do not count, so shadows never leak across silhouettes.
// The roughness (g) is averaged over all taps without depth weights: high on see-through cutout
// textures (leaves, grass), zero in solid corners; the occlusion fades out there (no dots, no flicker).
// v4: mask starts later (0.1..0.34 instead of 0.06..0.25), Dreh v3 showed it also removed the shadows on meadows.
float ao_filtered(vec2 uv, float reversed, out float z0) {
    z0 = linear_depth(texture(DepthSampler, uv).r, reversed);
    float tol = 0.25 + z0 * 0.04;
    vec2 c0 = texture(AoSampler, uv).rg;
    float acc = c0.r * 2.0;
    float total = 2.0;
    float rough = c0.g * 2.0;
    for (int i = 0; i < 4; i++) {
        vec2 o = vec2(i < 2 ? -2.0 : 2.0, (i % 2 == 0) ? -2.0 : 2.0) / AoSize;
        float z = linear_depth(texture(DepthSampler, uv + o).r, reversed);
        float w = 1.0 - smoothstep(tol * 0.5, tol, abs(z - z0));
        vec2 a = texture(AoSampler, uv + o).rg;
        acc += a.r * w;
        total += w;
        rough += a.g;
    }
    return acc / max(total, 1e-4) * (1.0 - smoothstep(0.1, 0.34, rough / 6.0));
}

void main() {
    vec2 px = 1.0 / SceneSize;
    vec3 raw = texture(SceneSampler, texCoord).rgb;
    vec3 scene = raw;
    if (Sharpen > 0.0) {
        vec3 cross = texture(SceneSampler, texCoord + vec2(px.x, 0.0)).rgb
                   + texture(SceneSampler, texCoord - vec2(px.x, 0.0)).rgb
                   + texture(SceneSampler, texCoord + vec2(0.0, px.y)).rgb
                   + texture(SceneSampler, texCoord - vec2(0.0, px.y)).rgb;
        // limit the boost so block edges do not get bright or dark seams
        scene = clamp(scene + clamp((scene - cross * 0.25) * Sharpen, -0.06, 0.06), 0.0, 1.0);
    }

    float reversed = 0.0;
    float ao = 0.0;
    float z0 = 0.0;
    bool sky = false;
    if (AoStrength > 0.0 || SkyBoost > 0.0) {
        reversed = texture(DepthSampler, vec2(0.5)).r < 0.5 ? 1.0 : 0.0;
        sky = depth_x(texture(DepthSampler, texCoord).r, reversed) < 1e-6;
    }
    if (AoStrength > 0.0 && !sky) {
        ao = ao_filtered(texCoord, reversed, z0);
    }

    vec3 lin = pow(scene, vec3(2.2));
    lin *= 1.0 - clamp(ao * AoStrength, 0.0, 0.85);
    vec3 glow = LiteGlow > 0.0 ? lite_glow(texCoord) * LiteGlow : texture(GlowSampler, texCoord).rgb;
    lin += glow * GlowMix;
    lin *= Exposure;
    // the roll-off darkens mid tones a little; scale back so a mid grey stays where it was
    float midFix = 0.18 / max(luma(rolloff(vec3(0.18), WhitePoint)), 1e-4);
    lin = rolloff(lin * midFix, WhitePoint);

    vec3 c = pow(clamp(lin, 0.0, 1.0), vec3(1.0 / 2.2));
    // contrast S-curve, but the dark end is protected (v2 made nights darker than Vanilla):
    // below about 0.35 luma the curve fades out, so shadows and night scenes keep their level
    c = mix(c, c * c * (3.0 - 2.0 * c), Contrast * smoothstep(0.08, 0.38, luma(c)));

    float l = luma(c);
    // v6: cool shadow tint at full strength in dark pixels again (v4 night look; the v5 fade-out is gone)
    float shadowW = (1.0 - l) * (1.0 - l) * ShadowTint.a;
    float highW = l * l * HighlightTint.a;
    c *= mix(vec3(1.0), ShadowTint.rgb, shadowW);
    c *= mix(vec3(1.0), HighlightTint.rgb, highW);

    l = luma(c);
    float hi = max(max(c.r, c.g), c.b);
    float chroma = hi - min(min(c.r, c.g), c.b);
    float sat = Saturation;
    if (sky) {
        // pale horizon (= haze colour) stays as it is, so far terrain still melts into the sky;
        // strongly coloured sky (zenith, sunset) gets deeper
        sat += SkyBoost * clamp(chroma * 2.5, 0.0, 1.0);
    } else {
        sat += Vibrance * (1.0 - clamp(chroma * 2.0, 0.0, 1.0));
    }
    // warm hues: red clearly above blue, green in between (orange, gold, amber)
    float warm = clamp((c.r - c.b) * 2.5, 0.0, 1.0) * clamp(1.0 - abs((c.g - c.b) / max(c.r - c.b, 1e-4) - 0.5) * 2.0, 0.0, 1.0);
    sat += WarmBoost * warm;
    c = mix(vec3(l), c, sat);

    vec2 d = texCoord - 0.5;
    d.x *= OutSize.x / OutSize.y;
    float v = 1.0 - Vignette * smoothstep(Falloff * 0.5, Falloff * 0.5 + 0.55, length(d));
    c = clamp(c * v, 0.0, 1.0);

    if (Split > 0.0 && texCoord.x < Split) {
        c = raw;
        if (Debug > 1.5) {
            c = sky ? vec3(0.35, 0.75, 1.0) : vec3(1.0 - clamp(ao * 2.0, 0.0, 1.0));
        }
    }
    if (Split > 0.0 && abs(texCoord.x - Split) < 1.0 / OutSize.x) {
        c = vec3(1.0);
    }
    fragColor = vec4(c, 1.0);
}
