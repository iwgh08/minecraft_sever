#version 330
#extension GL_ARB_separate_shader_objects : require

// NoMod Shaders v6 Cinematic: depth of field with automatic focus on the subject in the middle of the screen.
// v5 (Dreh v4: in sunset_hunter the Hunter 6 blocks ahead was blurred and only the sky was sharp):
// - focus = weighted mean of 1/distance over a 3x3 field around the centre (about 8 % of the screen height),
//   sky samples do not count, nearer samples count more (the subject is usually in front of the background).
//   Without a buffer that survives the frame there is no smoothing over time; the 9-sample field keeps the
//   focus steady when the centre pixel hits a gap (between legs, past a shoulder).
// - in-focus band: blur only starts clearly in front of and behind the focus plane (about 0.74x to 1.5x the
//   focus distance stays sharp), then grows like a lens with the difference in 1/distance.
// - 16 taps on a golden-angle spiral (v4: 24), and no taps at all inside the in-focus band.
// v6 (FPS, Dreh v5: Cinematic ca. 280, Default ca. 305): same picture, less work per pixel: the spiral
//   directions are a constant table (no sin/cos per tap), the centre depth is read once (it also decides
//   reversed depth), and very small blur radii (under 1.5 px at 1080p, the soft edge of the in-focus band)
//   use the first 8 spiral taps on the same disc (tools/dof_check.py: 3 px was measurable on fine patterns,
//   1.5 px is not; the bokeh keeps 16).
// Each tap only counts if that sample is itself out of focus enough to reach this pixel, so a sharp subject
// does not smear into the blurred background (no halo). Works for normal and reversed depth buffers.
// Debug > 0: tints the blur (near blue, far red) and marks the focus field with a small white cross.

uniform sampler2D SceneSampler;
uniform sampler2D DepthSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 SceneSize;
    vec2 DepthSize;
};

layout(std140) uniform K1Dof {
    float Strength;   // blur per unit of 1/distance beyond the in-focus band (1/blocks)
    float MaxRadius;  // largest blur radius in pixels at 1080p (scales with the screen height)
    float Band;       // half width of the in-focus band as share of the focus 1/distance
    float Near;       // near clipping plane in blocks
    float Debug;      // 1 = tint the out-of-focus areas
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float depth_x(float d, float reversed) {
    return reversed > 0.5 ? d : 1.0 - d;
}

// returns 1/distance (affine in the true 1/distance, which is all the lens formula needs); sky = 0
float inv_dist(float d, float reversed) {
    return depth_x(d, reversed) / Near;
}

// golden-angle spiral directions (angle = i * 2.39996 rad, i = 1..16)
const vec2 K1_SPIRAL[16] = vec2[16](
    vec2(-0.737367, 0.675493),
    vec2(0.087419, -0.996172),
    vec2(0.608447, 0.793595),
    vec2(-0.984716, -0.174169),
    vec2(0.843747, -0.536742),
    vec2(-0.259586, 0.965720),
    vec2(-0.460927, -0.887438),
    vec2(0.939330, 0.343014),
    vec2(-0.924334, 0.381583),
    vec2(0.423817, -0.905748),
    vec2(0.299318, 0.954153),
    vec2(-0.865231, -0.501374),
    vec2(0.976667, -0.214760),
    vec2(-0.575092, 0.818088),
    vec2(-0.128559, -0.991702),
    vec2(0.764682, 0.644407));

float focus_value(float dCentre, float reversed) {
    vec2 o = vec2(0.04 * DepthSize.y / DepthSize.x, 0.04);
    float acc = 0.0;
    float total = 0.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            float d = (x == 0 && y == 0) ? dCentre : texture(DepthSampler, vec2(0.5) + vec2(float(x), float(y)) * o).r;
            float w = inv_dist(d, reversed);
            // sky (w ~ 0) has no weight; nearer samples weigh more (weight = 1/distance)
            float k = w > 1e-5 ? w * (x == 0 && y == 0 ? 2.0 : 1.0) : 0.0;
            acc += w * k;
            total += k;
        }
    }
    return total > 0.0 ? acc / total : 0.0;
}

// signed circle of confusion: > 0 near, < 0 far, 0 inside the in-focus band
float coc_of(float w, float focus) {
    float band = Band * focus + 0.0015;
    float d = w - focus;
    return clamp(sign(d) * max(abs(d) - band, 0.0) * Strength, -1.0, 1.0);
}

void main() {
    float dCentre = texture(DepthSampler, vec2(0.5)).r;
    float reversed = dCentre < 0.5 ? 1.0 : 0.0;
    float focus = focus_value(dCentre, reversed);
    float maxR = MaxRadius * SceneSize.y / 1080.0;
    float w0 = inv_dist(texture(DepthSampler, texCoord).r, reversed);
    float coc = coc_of(w0, focus);
    float radius = abs(coc) * maxR;

    vec3 acc = texture(SceneSampler, texCoord).rgb;
    float total = 1.0;
    if (radius > 0.6) {
        int taps = radius < 1.5 * SceneSize.y / 1080.0 ? 8 : 16;
        float invTaps = 1.0 / float(taps);
        for (int i = 1; i <= 16; i++) {
            if (i > taps) {
                break;
            }
            float dist = sqrt(float(i) * invTaps) * radius;
            vec2 off = K1_SPIRAL[i - 1] * dist / SceneSize;
            float ws = inv_dist(texture(DepthSampler, texCoord + off).r, reversed);
            float sampleR = abs(coc_of(ws, focus)) * maxR;
            float reach = clamp(sampleR - dist + 1.0, 0.0, 1.0);
            // nearer samples only spread if they are blurred themselves (foreground bokeh over the
            // background yes, a sharp subject over the blurred background no); farther ones always count
            float w = ws > w0 ? reach : 1.0;
            acc += texture(SceneSampler, texCoord + off).rgb * w;
            total += w;
        }
    }
    vec3 c = acc / total;
    if (Debug > 0.5) {
        vec3 tint = coc > 0.0 ? vec3(0.4, 0.6, 1.6) : vec3(1.6, 0.5, 0.4);
        c = mix(c, c * tint, clamp(abs(coc) * 1.5, 0.0, 1.0));
        vec2 p = (texCoord - 0.5) * SceneSize;
        if ((abs(p.x) < 1.0 && abs(p.y) < 0.04 * SceneSize.y) || (abs(p.y) < 1.0 && abs(p.x) < 0.04 * SceneSize.y)) {
            c = vec3(1.0);
        }
    }
    fragColor = vec4(c, 1.0);
}
