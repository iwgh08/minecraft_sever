#version 330
#extension GL_ARB_separate_shader_objects : require

// K1 helper: copies a target unchanged (used to write a result back to the game frame).

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);
}
