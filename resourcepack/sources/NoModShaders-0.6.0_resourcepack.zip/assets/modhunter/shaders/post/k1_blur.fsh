#version 330
#extension GL_ARB_separate_shader_objects : require

// K1 v2 glow: one direction of a separable gaussian blur, 9 taps.
// In the first pass (BrightStrength > 0) every tap is first reduced to its bright part
// (sun, sky glow, lit water, torches, lanterns) and turned into linear light, so the glow adds
// up like light does. Later passes only blur. Two rounds (narrow, wide) give a soft, wide glow.

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform K1Blur {
    vec2 Direction;        // (1,0) horizontal, (0,1) vertical
    float Spread;          // distance between taps in pixels
    float Threshold;       // luma where the glow starts (gamma space)
    float Knee;            // width of the soft start
    float BrightStrength;  // 0 = plain blur, > 0 = extract the bright part first
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

float luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

vec3 bright_part(vec3 c) {
    float l = luma(c);
    // soft knee: quadratic ramp between Threshold - Knee and Threshold + Knee, linear above
    float t = clamp(l - Threshold + Knee, 0.0, 2.0 * Knee);
    float ramp = (t * t) / (4.0 * Knee + 1e-4);
    float w = max(ramp, l - Threshold) / max(l, 1e-4);
    return pow(c, vec3(2.2)) * w * BrightStrength;
}

void main() {
    vec2 stepUv = Direction * Spread / InSize;
    vec3 acc = vec3(0.0);
    float total = 0.0;
    for (int i = -4; i <= 4; i++) {
        float x = float(i);
        float w = exp(-x * x / 8.0);  // sigma = 2 taps
        vec3 c = texture(InSampler, texCoord + stepUv * x).rgb;
        if (BrightStrength > 0.0) {
            c = bright_part(c);
        }
        acc += c * w;
        total += w;
    }
    fragColor = vec4(acc / total, 1.0);
}
