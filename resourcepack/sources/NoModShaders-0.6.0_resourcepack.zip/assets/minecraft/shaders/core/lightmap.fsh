#version 330
#extension GL_ARB_separate_shader_objects : require

// NoMod Shaders v6 (K1 Day 6) replacement of the lightmap program (Minecraft 26.3). The game draws a 16x16
// table here: x = block light level, y = sky light level; every lit surface looks up its colour in it.
// The input block must match the game. Changes against the normal look:
// - torches, lanterns, campfires and fire light are clearly warmer (amber) in the mid range,
//   close to the source they stay bright and warm white
// - golden hour, tuned with the Day-3 calibration (own measurement, README "Kalibrierung"): SkyFactor is
//   ~1.0 at noon, 0.9-0.995 at tick 11500, 0.6-0.7 at 12100, 0.5-0.6 at 12300-12400, 0.3-0.4 at 12800,
//   0.2-0.3 at night, 0.4-0.5 at sunrise (23300); the brightness of SkyLightColor drops to 0.7-0.8 around
//   sunset, and its hue stays slightly blue-lavender all day (the game never tints sky light warm).
//   So the golden band now sits on SkyFactor 0.3..0.98 (full 0.48..0.8), gated off when SkyLightColor is
//   at full noon brightness, and replaces the lavender sky light by gold of the same brightness.
//   Noon (SkyFactor >= 0.98) stays exactly neutral.
// - dim sky light (shade, blue hour, moonlight) gets a cooler tint with the same brightness; at night the
//   sky part is lifted (moonlight) and a faint cool floor keeps terrain readable, aiming at Vanilla level.
//   v6: the night is exactly the v4 night again (cosy, bright, cool-blue moonlight; Matthias 01.11. after
//   comparing v4 and v5 at night: "Ich finde v4 gemütlicher"): v4 cool tint 0.84/0.98/1.36, no hue
//   neutralisation, v4 cool floor. Daytime shade keeps the milder v5 tint; the two tints are blended with the
//   same night weight that drives the moonlight lift (SkyFactor 0.45 -> 0.3), so dusk and dawn have no step.
// - night vision, darkness, boss fog and the Brightness slider work as before.
// Calibration false colours (K1_CAL = 1, not used in any built pack since v4): no block light -> SkyFactor
// in 0.1 steps; block light 7-10 -> brightness of SkyLightColor; block light 11-15 -> SkyLightColor hue.

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} light;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const vec3 K1_WARM = vec3(1.0, 0.66, 0.38);     // torch light in the mid range
const float K1_WARM_MIX = 0.8;
const vec3 K1_COOL = vec3(0.92, 0.99, 1.16);    // dim sky light by day (shade, blue hour), luminance ~1 (v5)
const vec3 K1_COOL_NIGHT = vec3(0.84, 0.98, 1.36);  // dim sky light at night = cool-blue moonlight (v4, back in v6)
const vec3 K1_GOLD = vec3(1.34, 0.93, 0.5);     // golden hour sky light (luminance ~0.98, replaces the lavender hue)
const float K1_GOLD_MIX = 0.9;
const float K1_NIGHT_LIFT = 0.5;                // extra sky light share at night (moonlight), v3 0.22
const vec3 K1_NIGHT_FLOOR = vec3(0.018, 0.022, 0.032);  // faint cool base light at night (v4, back in v6; v5 0.022/0.024/0.028)
const float K1_CAL = 0.0;                       // 1 = calibration false colours (v3 diagnosis)

// light level (0..1) to brightness, same falloff family as the game
float level_curve(float level) {
    return level / (4.0 - 3.0 * level);
}

// the game's "Brightness" slider lifts dark values with a curve that keeps white at white
vec3 lift_dark(vec3 c) {
    float top = max(max(c.r, c.g), c.b);
    float inv = 1.0 - top;
    float lifted = 1.0 - inv * inv * inv * inv;
    return c * (lifted / max(top, 1e-5));
}

float k1_luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// calibration palette: one clearly named colour per 0.1 step (README "Kalibrier-Diagnose")
vec3 k1_palette(float v) {
    if (v < 0.0) return vec3(0.0, 0.0, 0.0);          // below 0: black
    if (v < 0.1) return vec3(0.4, 0.4, 0.4);          // 0.0-0.1 grey
    if (v < 0.2) return vec3(0.55, 0.0, 0.9);         // 0.1-0.2 violet
    if (v < 0.3) return vec3(0.05, 0.2, 1.0);         // 0.2-0.3 blue
    if (v < 0.4) return vec3(0.0, 0.85, 1.0);         // 0.3-0.4 cyan
    if (v < 0.5) return vec3(0.0, 0.85, 0.15);        // 0.4-0.5 green
    if (v < 0.6) return vec3(1.0, 1.0, 0.0);          // 0.5-0.6 yellow
    if (v < 0.7) return vec3(1.0, 0.5, 0.0);          // 0.6-0.7 orange
    if (v < 0.8) return vec3(1.0, 0.0, 0.0);          // 0.7-0.8 red
    if (v < 0.9) return vec3(0.5, 0.25, 0.08);        // 0.8-0.9 brown
    if (v < 0.995) return vec3(1.0, 0.55, 0.75);      // 0.9-0.995 pink
    if (v < 1.05) return vec3(1.0, 1.0, 1.0);         // 0.995-1.05 white (= full day)
    return vec3(0.0, 0.3, 0.1);                       // above 1.05: dark green
}

vec3 k1_calibration(float blockLevel, float skyLevel) {
    if (blockLevel > 10.5 / 15.0) {
        vec3 c = light.SkyLightColor;
        return c / max(max(max(c.r, c.g), c.b), 1e-4);
    }
    if (blockLevel > 6.5 / 15.0) {
        return k1_palette(k1_luma(light.SkyLightColor));
    }
    // keep a little of the sky level so shapes stay readable, the hue carries the value
    return k1_palette(light.SkyFactor) * (0.6 + 0.4 * skyLevel);
}

void main() {
    float blockLevel = floor(texCoord.x * 16.0) / 15.0;
    float skyLevel = floor(texCoord.y * 16.0) / 15.0;

    float blockLight = level_curve(blockLevel) * light.BlockFactor;
    float skyLight = level_curve(skyLevel) * light.SkyFactor;

    vec3 color = max(light.AmbientColor, light.NightVisionColor * light.NightVisionFactor);

    // golden hour on the measured SkyFactor curve (see header): rises from 0.3 (dusk) to full at 0.48,
    // stays full to 0.8 (12100-12400 and sunrise), gone at 0.98 (noon). Gate: at full noon brightness of
    // SkyLightColor (luma >= 0.97) there is no golden hour, e.g. when rain alone dims SkyFactor.
    float sf = light.SkyFactor;
    float slLuma = k1_luma(light.SkyLightColor);
    float golden = smoothstep(0.3, 0.48, sf) * (1.0 - smoothstep(0.8, 0.98, sf));
    golden *= 1.0 - smoothstep(0.88, 0.97, slLuma);
    float night = 1.0 - smoothstep(0.3, 0.45, sf);

    // sky light: cooler when dim, neutral when strong, golden in the golden hour
    vec3 skyTint = mix(mix(K1_COOL, K1_COOL_NIGHT, night), vec3(1.0), smoothstep(0.2, 0.8, skyLight));
    vec3 skyColor = light.SkyLightColor * skyTint;
    float goldW = golden * K1_GOLD_MIX * smoothstep(0.3, 0.9, skyLevel);
    skyColor = mix(skyColor, K1_GOLD * slLuma, goldW);
    color += skyColor * skyLight * (1.0 + K1_NIGHT_LIFT * night);
    color += K1_NIGHT_FLOOR * night * (0.4 + 0.6 * skyLevel);

    // block light: warm in the middle levels, warm white right next to the source
    float nearSource = smoothstep(0.8, 1.0, blockLevel);
    vec3 warmTint = mix(light.BlockLightTint, light.BlockLightTint * K1_WARM, K1_WARM_MIX);
    vec3 blockTint = mix(warmTint, vec3(1.0, 0.9, 0.74), nearSource * (1.0 - K1_WARM_MIX * 0.5));
    color += blockTint * blockLight * 1.08;

    color = mix(color, color * vec3(0.7, 0.6, 0.6), light.BossOverlayWorldDarkeningFactor);
    color -= vec3(light.DarknessScale);
    color = clamp(color, 0.0, 1.0);
    color = mix(color, lift_dark(color), light.BrightnessFactor);

    if (K1_CAL > 0.5) {
        color = k1_calibration(blockLevel, skyLevel);
    }
    fragColor = vec4(color, 1.0);
}
