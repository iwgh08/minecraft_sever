#version 330
#extension GL_ARB_separate_shader_objects : require

// NoMod Shaders v5 (K1 Day 5): own terrain vertex program for Minecraft Java 26.3 with wind.
// Inputs, uniform blocks, defines and outputs are the same as the game's terrain program (all terrain passes
// use it: solid, cutout, translucent, multidraw and the OIT phases), only the position of some vertices changes.
//
// What moves (26.3 gives no block id to the shader, so blocks are recognised by their vertex data):
// - plants: biome-tinted green quads with a corner off the block grid in x OR z (crossed plants like short
//   grass, ferns, tall grass, sugar cane, bushes; v4 needed x AND z, which missed plants whose random offset
//   put one corner on the grid). Vines (flat 0.05 blocks off a wall, on the grid in the other axis) count as
//   foliage, not as plants. Only the two upper corners of each quad move, so the roots stay in the ground.
//   Which corner is up (v5, Dreh v4 showed the vertex-index rule swapped in some sections):
//   1. texture rule: if the game shrinks the texture coordinates a little toward the sprite centre (the
//      fraction inside the 16-pixel grid of the atlas is the same small amount in u and v), the upper corners
//      sit just below the top edge of the sprite -> exact, independent of the vertex buffer.
//   2. otherwise the vertex-index rule of v4 (corners 0 and 3 at the top, gl_VertexID mod 4).
//   The diagnosis pack paints which rule decided (README "Wind").
// - leaves and vines: biome-tinted quads in a strong foliage green (blue below 36 % of green). All their
//   corners move by the same smooth wind field of the world position, so neighbouring leaves share every
//   corner and no gaps open.
// What never moves: untinted blocks (stone, logs, flowers, crops, redstone torches, glass, cherry and other
// untinted leaves ...), water (blue tint), redstone wire (red tint), grass block tops and sides (corners on
// the block grid, grass green less saturated than foliage green), spruce and birch leaves (fixed tint).
// Limits in README "Wind".
// Time: GameTime from Globals runs 0..1 over 24000 ticks (20 minutes); all wind frequencies are whole
// cycles per day, so the motion never jumps when it wraps.
// Lines marked "diag:" are replaced by build.py in the diagnosis pack.

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV2;
#ifdef MULTIDRAW_TERRAIN
layout(location = 4) in ivec3 ChunkPosition;
layout(location = 5) in float ChunkVisibility;
#endif

#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out float chunkVisibility;

const float K1_WIND = 1.0;          // 0 = no motion at all (same as the "still" pack variant)
const float K1_PLANT_SWAY = 0.11;   // blocks, tip of a plant at full gust
const float K1_PLANT_LEAN = 0.05;   // blocks, steady lean with the wind
const float K1_LEAF_SWAY = 0.045;   // blocks, leaves and vines at full gust
const float K1_WIND_RANGE = 64.0;   // motion fades out up to this distance (no shimmer far away)
const int K1_TOP_A = 0;             // quad corners at the top of a plant (game: 0 and 3)
const int K1_TOP_B = 3;
const float K1_CORNER_UV = 1.0;     // 1 = try the texture rule first, 0 = vertex-index rule only (v4)
const float K1_WIND_DIAG = 0.0;     // 1 = paint moving vertices (README "Wind")  // diag: 1.0
const vec2 K1_WIND_DIR = vec2(0.91, 0.41);
const float K1_TAU = 6.2831853;

int k1_corner() {
#ifdef VULKAN
    return gl_VertexIndex & 3;
#else
    return gl_VertexID & 3;
#endif
}

// distance of a coordinate to the nearest block grid line
float k1_grid(float v) {
    float f = fract(v);
    return min(f, 1.0 - f);
}

// 0 = still, 1 = plant (bends), 2 = leaves/vines (moves as a whole)
int k1_kind(vec3 local, vec3 c) {
    // biome green: green clearly above blue, not below red (v5 looser: dry and cold biome greens), not grey
    float hi = max(max(c.r, c.g), c.b);
    float lo = min(min(c.r, c.g), c.b);
    bool green = c.g > 0.03 && c.g > c.r * 0.95 && c.g > c.b * 1.1 && hi - lo > 0.08 * hi;
    if (!green) {
        return 0;
    }
    float gx = k1_grid(local.x);
    float gz = k1_grid(local.z);
    // a vine lies 0.8/16 = 0.05 blocks off a block face and on the grid in the other axis
    bool vine = (abs(gx - 0.05) < 0.004 && gz < 0.002) || (abs(gz - 0.05) < 0.004 && gx < 0.002);
    if ((gx > 0.02 || gz > 0.02) && !vine) {
        return 1;
    }
    return c.b < c.g * 0.36 ? 2 : 0;
}

// which corner of a plant quad is up: 1 = top, 0 = root, -1 = texture rule cannot tell
int k1_uv_top(vec2 uv) {
    vec2 t = uv * vec2(TextureSize) / 16.0;
    vec2 f = fract(t);
    vec2 d = min(f, 1.0 - f);
    // a shrink toward the sprite centre is small, present in u and v, and the same size in both
    if (TextureSize.x <= 0 || TextureSize.y <= 0) {
        return -1;
    }
    if (d.x < 1e-4 || d.y < 1e-4 || d.x > 0.03 || d.y > 0.03 || abs(d.x - d.y) > 0.3 * max(d.x, d.y)) {
        return -1;
    }
    // just below the top edge of the sprite (small fraction above a grid line) = upper corner
    return f.y < 0.5 ? 1 : 0;
}

// gust strength 0.25..1, a slow front that travels with the wind across the land
float k1_gust(vec3 world, float t) {
    float front = sin(t * 150.0 - dot(world.xz, K1_WIND_DIR) * 0.09);
    float slow = sin(t * 61.0 + dot(world.xz, vec2(-0.41, 0.91)) * 0.05);
    float g = 0.5 + 0.35 * front + 0.15 * slow;
    return 0.25 + 0.75 * clamp(g, 0.0, 1.0);
}

// corner: 1 = upper corner of a plant (moves), 0 = root (still)
vec3 k1_wind(vec3 world, int kind, int corner, float t) {
    float gust = k1_gust(world, t);
    if (kind == 1) {
        if (corner == 0) {
            return vec3(0.0);
        }
        float phase = dot(world.xz, vec2(0.83, 0.57)) + world.y * 0.31;
        float sway = sin(t * 660.0 + phase) * 0.7 + sin(t * 1140.0 + phase * 1.7) * 0.3;
        float flutter = sin(t * 2100.0 + world.x * 2.3 + world.z * 1.9);
        vec2 side = vec2(-K1_WIND_DIR.y, K1_WIND_DIR.x);
        vec2 d = K1_WIND_DIR * (K1_PLANT_LEAN + K1_PLANT_SWAY * sway) * gust + side * 0.025 * flutter * gust;
        // a bent blade gets a little shorter
        return vec3(d.x, -1.2 * dot(d, d), d.y);
    }
    if (kind == 2) {
        vec3 w = vec3(sin(t * 780.0 + world.x * 1.7 + world.y * 1.3 + world.z * 0.4),
                      sin(t * 900.0 + world.z * 1.9 + world.x * 0.7) * 0.45,
                      sin(t * 840.0 + world.z * 1.5 + world.y * 1.1 - world.x * 0.3));
        float push = sin(t * 360.0 + dot(world.xz, vec2(0.5, 0.3)));
        w.xz += K1_WIND_DIR * (0.6 + 0.4 * push);
        return w * K1_LEAF_SWAY * gust;
    }
    return vec3(0.0);
}

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    vec3 diagTint = vec3(1.0);

    if (K1_WIND > 0.5) {
        vec3 world = Position + vec3(ChunkPosition);
        int kind = k1_kind(Position, Color.rgb);
        float fade = 1.0 - smoothstep(K1_WIND_RANGE * 0.6, K1_WIND_RANGE, length(pos));
        if (kind != 0 && fade > 0.0) {
            int top = 0;
            int rule = 0;   // 1 = texture rule, 0 = vertex-index rule
            if (kind == 1) {
                int uvTop = K1_CORNER_UV > 0.5 ? k1_uv_top(UV0) : -1;
                if (uvTop >= 0) {
                    top = uvTop;
                    rule = 1;
                } else {
                    int corner = k1_corner();
                    top = (corner == K1_TOP_A || corner == K1_TOP_B) ? 1 : 0;
                }
            }
            pos += k1_wind(world, kind, top, GameTime * K1_TAU) * fade;
            if (K1_WIND_DIAG > 0.5) {
                // texture rule: top red, root blue; vertex-index rule: top orange, root cyan; leaves yellow
                vec3 topTint = rule == 1 ? vec3(2.2, 0.2, 0.2) : vec3(2.2, 1.0, 0.1);
                vec3 rootTint = rule == 1 ? vec3(0.2, 0.4, 2.2) : vec3(0.1, 1.6, 1.8);
                diagTint = kind == 2 ? vec3(1.6, 1.5, 0.2) : (top == 1 ? topTint : rootTint);
            }
        }
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
#ifndef OIT_ALPHA_ONLY
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    vertexColor.rgb *= diagTint;
    texCoord0 = UV0;

    // sections fade in from 16 blocks on, fully faded at 32 (as in the game)
    chunkVisibility = mix(1.0, ChunkVisibility, clamp(length(pos) / 16.0 - 1.0, 0.0, 1.0));
}
