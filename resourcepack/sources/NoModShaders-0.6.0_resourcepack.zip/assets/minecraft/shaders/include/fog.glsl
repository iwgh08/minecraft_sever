#ifndef MINECRAFT_FOG_GLSL
#define MINECRAFT_FOG_GLSL

// NoMod Shaders v6 (K1 Day 6) replacement of the shared fog include (Minecraft 26.3, resource pack 97.1).
// The uniform block and the five function signatures must stay exactly as the game expects,
// because every world shader includes this file. On top of the normal fog: a light distance haze
// (aerial perspective) in the middle distance only. v5 rule (Dreh v4: high cameras looking down lost the
// whole bay in the haze): the haze is NEVER stronger than the game's own fog plus a small extra in the
// middle distance, and at the edge of the render distance it is exactly the game's fog.
// - distance like the game's edge fog: cylindrical (max of horizontal distance and height difference),
//   not the straight-line distance, so terrain far below a high camera is not counted as "far away"
// - slant: lines of sight with a large second component (terrain far below or above at a diagonal) get
//   up to 50 % less haze, so bays seen from above stay as readable as in Vanilla
// - extra haze rises from 40 % of the render distance to at most K1_HAZE_AMOUNT (14 %) and falls back to 0
//   where the game's fog starts; combined with the game fog as two veils 1 - (1-a)(1-b) <= a + b
// - at night the extra is weaker (dark fog colour), so far terrain is never darker than Vanilla
// - v6: at night (dark fog colour) the haze is exactly the v4 night haze again (straight-line distance, up to
//   78 % x 0.35 of the dark-blue fog colour at the edge), part of the cosy v4 moonlight look Matthias chose on
//   01.11.; by day it is the v5 haze. Both are blended with the night weight below (fog luma 0.3 -> 0.04),
//   so dusk and dawn have no step.
// The fog colour follows time of day, biome and view direction: golden toward a sunset, dark blue at night.
// The haze stays off for the sky dome itself and inside short environmental fog
// (lava, powder snow, blindness, darkness), where the game already sets a near fog end.
// Lines marked "diag:" are replaced by build.py in the diagnosis pack (same haze, painted magenta).

layout(std140) uniform Fog {
    vec4 FogColor;
    float FogEnvironmentalStart;
    float FogEnvironmentalEnd;
    float FogRenderDistanceStart;
    float FogRenderDistanceEnd;
    float FogSkyEnd;
    float FogCloudsEnd;
};

const float K1_HAZE_AMOUNT = 0.14;              // largest extra haze in the middle distance (v4: 0.78 at the edge)
const float K1_HAZE_NIGHT = 0.35;               // haze share left when the fog colour is dark (night)
const float K1_HAZE_FROM = 0.4;                 // haze starts at this share of the render distance
const float K1_HAZE_MIN_START = 24.0;           // but never closer than this many blocks (short render distances)
const float K1_HAZE_SLANT = 0.5;                // up to this share less haze on steep lines of sight
const float K1_HAZE_NIGHT_EDGE = 0.78;          // v4 night haze: share of fog colour at the edge (times K1_HAZE_NIGHT)
const float K1_DIAG = 0.0;                      // 1 = paint the haze magenta  // diag: 1.0
const vec3 K1_DIAG_COLOR = vec3(1.0, 0.0, 1.0);

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    float span = fogEnd - fogStart;
    if (span <= 0.0) {
        return vertexDistance >= fogEnd ? 1.0 : 0.0;
    }
    return clamp((vertexDistance - fogStart) / span, 0.0, 1.0);
}

// extra haze on top of the game's fog; uses the same distances the game passes to the fog functions
float k1_haze_value(float spherical, float cylindrical, float environmentalEnd, float renderDistanceStart, float renderDistanceEnd, vec3 fogColor) {
    // the sky dome is drawn with start == end: no extra haze there
    if (renderDistanceEnd - renderDistanceStart < 1.0) {
        return 0.0;
    }
    // very short environmental fog means lava, powder snow, blindness or darkness
    float open = smoothstep(20.0, 60.0, environmentalEnd);
    float start = min(max(renderDistanceEnd * K1_HAZE_FROM, K1_HAZE_MIN_START), renderDistanceEnd * 0.7);
    // rises over 60 % of the way from start to the place where the game's own fog begins
    float top = max(renderDistanceStart, start + 1.0);
    float x = clamp((cylindrical - start) / max((top - start) * 0.6, 1.0), 0.0, 1.0);
    float rise = x * x * (3.0 - 2.0 * x);
    // falls back to 0 across the game's fog band: at the edge only the game's fog is left
    float fall = 1.0 - smoothstep(top, renderDistanceEnd, cylindrical);
    // second component of the line of sight (height difference or sideways distance, whichever is smaller)
    float minor = sqrt(max(spherical * spherical - cylindrical * cylindrical, 0.0));
    float slant = 1.0 - K1_HAZE_SLANT * smoothstep(0.2, 0.7, minor / max(cylindrical, 1.0));
    // dark fog colour = night: a dark veil would only darken far terrain
    float fogLuma = dot(fogColor, vec3(0.2126, 0.7152, 0.0722));
    float dayW = smoothstep(0.04, 0.3, fogLuma);
    float dayShare = mix(K1_HAZE_NIGHT, 1.0, dayW);
    float hazeDay = rise * fall * slant * K1_HAZE_AMOUNT;
    // v4 night haze (straight-line distance, rises to the edge of the render distance)
    float xn = clamp((spherical - start) / max(renderDistanceEnd - start, 1.0), 0.0, 1.0);
    float hazeNight = xn * xn * (3.0 - 2.0 * xn) * K1_HAZE_NIGHT_EDGE;
    return open * mix(hazeNight, hazeDay, dayW) * dayShare;
}

float k1_base_fog(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    float environmental = linear_fog_value(sphericalVertexDistance, environmentalStart, environmantalEnd);
    float edge = linear_fog_value(cylindricalVertexDistance, renderDistanceStart, renderDistanceEnd);
    return max(environmental, edge);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    float base = k1_base_fog(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
    float haze = k1_haze_value(sphericalVertexDistance, cylindricalVertexDistance, environmantalEnd, renderDistanceStart, renderDistanceEnd, FogColor.rgb);
    // both layers add up like two veils of air: 1 - (1 - a)(1 - b)
    return 1.0 - (1.0 - base) * (1.0 - haze);
}

vec4 apply_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor) {
    float base = k1_base_fog(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
    float haze = k1_haze_value(sphericalVertexDistance, cylindricalVertexDistance, environmantalEnd, renderDistanceStart, renderDistanceEnd, fogColor.rgb);
    vec3 hazeColor = mix(fogColor.rgb, K1_DIAG_COLOR, K1_DIAG);
    vec3 c = mix(inColor.rgb, hazeColor, haze * fogColor.a);
    return vec4(mix(c, fogColor.rgb, base * fogColor.a), inColor.a);
}

float fog_spherical_distance(vec3 pos) {
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    return max(length(pos.xz), abs(pos.y));
}

#endif
